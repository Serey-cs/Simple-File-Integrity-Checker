package main

import (
    "crypto/sha256"
    "encoding/hex"
    "io"
    "os"
)

// computeSHA256 takes a file path and returns its SHA-256 hash as a string
func computeSHA256(path string) (string, error) {
    // open the file
    file, err := os.Open(path)
    if err != nil {
        return "", err // return error if file can't be opened
    }
    defer file.Close() // make sure we close it at the end

    // create a new SHA-256 hasher
    hasher := sha256.New()

    // copy the file content into the hasher
    if _, err := io.Copy(hasher, file); err != nil {
        return "", err
    }

    // get the hash as bytes
    hashBytes := hasher.Sum(nil)

    // convert bytes to a readable hex string
    return hex.EncodeToString(hashBytes), nil
}
